# This file is intentionally left empty to mark the directory as a Python package 

from flask_sqlalchemy import SQLAlchemy
from .ad_model import Ad, Category

db = SQLAlchemy() 