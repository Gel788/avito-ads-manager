#!/bin/bash

# Этот скрипт загружает код в GitHub репозиторий
# Замените USER_NAME на ваше имя пользователя GitHub
# Замените TOKEN на ваш персональный токен доступа GitHub

USER_NAME="albertgiloan"
TOKEN="ваш_токен_github"
REPO_NAME="avito-ads-manager"

# Удаление текущих настроек удаленного репозитория
git remote remove origin

# Добавление нового удаленного репозитория с токеном
git remote add origin https://$USER_NAME:$TOKEN@github.com/$USER_NAME/$REPO_NAME.git

# Отправка кода
git push -u origin main

echo "Код успешно загружен в репозиторий $REPO_NAME" 